$(document).ready(function(){
	$('.restore').click(function(){
		$('img').fadeIn();
	})

	$('img').click(function(){
		$(this).slideUp();
	})
})
