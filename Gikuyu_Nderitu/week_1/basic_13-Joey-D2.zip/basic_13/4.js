function print_array(arr) {
	for(var i = 0; i < arr.length; i++){
		console.log(arr[i]);
	}
}

print_array([0,1,2,3,4,5,6,7,8,9,10])
